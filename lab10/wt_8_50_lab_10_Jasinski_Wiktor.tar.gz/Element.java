public class Element{
    private String m_str1;
    private String m_str2;

    Element(String str1, String str2){
        m_str1 = str1;
        m_str2 = str2;
    }

    String getStr1(){return m_str1;}
    String getStr2(){return m_str2;}
}