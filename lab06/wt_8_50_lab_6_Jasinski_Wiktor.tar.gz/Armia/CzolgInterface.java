package Armia;

interface CzolgInterface{
  
    public String ostatniRozkaz();
    public void setRozkaz(Rozkaz rozkaz);
    public String getRozkazy();
}