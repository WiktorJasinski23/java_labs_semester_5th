package Armia;

interface RozkazInterface{
    public String getRozkaz();
}