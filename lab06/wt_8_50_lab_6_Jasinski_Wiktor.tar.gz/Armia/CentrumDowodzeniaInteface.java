package Armia;

interface CentrumDowodzeniaInteface{
  
    public void zarejestrujCzolg(Czolg czolg);
    public void wydajRozkaz(String numerCzolgu, Rozkaz rozkaz);
    public String toString();

}